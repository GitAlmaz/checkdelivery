<template>
  <div class="home">
    <div class="container">
      <div class="active-content">
				<div class="col-6">
					<h1>About</h1>
			
				</div>
      </div>
      <div class="result-content">
        
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Home',
  components: {
  }
}
</script>
